<?php
header('Access-Control-Allow-Origin: *');
file_put_contents('assets/palaute.json', $_GET['json'])
?>
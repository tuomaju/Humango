import {Injectable} from '@angular/core';

@Injectable()
export class HaasteetService {

    palauteObj = [
        {
            palaute: 'testi',
            haasteId: '1'
        }
    ];

    constructor() {
    }

}
